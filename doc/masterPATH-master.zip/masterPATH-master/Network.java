package masterPATH;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Natalia Rubanova
 */
public class Network {

    Map<String, Node> nodes;
    Map<String, Interaction> interactions;

    /**
     *
     */
    public Network() {
        this.nodes = new HashMap();
        this.interactions = new HashMap();
    }

    /**
     * Saves all interactions in the network to the output file
     *
     * @param file output file
     * @throws IOException
     */
    public void print_interactions_to_file(String file) throws IOException {
        //      String id,List<String> other_ids, Node int1, Node int2, String type, String sourcedb,List<String []> sourcedbentry, String quality, String dir
        BufferedWriter wr = new BufferedWriter(new FileWriter(file));
        for (String id : interactions.keySet()) {
            wr.write(id + "\t");
            for (String s : interactions.get(id).other_ids) {
                wr.write(s + ";");
            }

            //       wr.write(interactions.get(id).sourcedbentry.get(0)[0] + "\t" + interactions.get(i).sourcedbentry.get(0)[2] + "\t" + interactions.get(i).sourcedbentry.get(0)[5] + "\t" + "");
            wr.newLine();
        }
        wr.close();
    }

    /**
     * Load network from two files
     *
     * @param nodef file with information about nodes
     * @param intf file with information about interactions
     * @throws FileNotFoundException
     * @throws IOException
     */
    public void loadNetworkfromfile(String nodef, String intf) throws FileNotFoundException, IOException {
        //String id, String type, String id_type, String db_flag, List<String[]> ids  
        BufferedReader rn = new BufferedReader(new FileReader(nodef));
        BufferedReader ri = new BufferedReader(new FileReader(intf));
        String s, t;
        String[] ss, tt;
        Node n;
        Interaction in;
        List<String[]> ls;
        List<String> ls1, ls2;

        while ((s = rn.readLine()) != null) {
            ss = s.split("\t");
            ls = new ArrayList();
            try {
                tt = ss[4].split(";");
                for (String r : tt) {
                    ls.add(r.split("_"));
                }
                n = new Node(ss[0], ss[1], ss[2], ss[3], ls);
                this.nodes.put(ss[0], n);
            } catch (ArrayIndexOutOfBoundsException e) {
                //System.out.println(s);
                ls.add(new String[]{"_"});
                n = new Node(ss[0], ss[1], ss[2], ss[3], ls);
                this.nodes.put(ss[0], n);
            }

        }

        //String id, List<String> other_ids, Node int1, Node int2, String type, String sourcedb, 
        //List<String> sourcedbentry, String quality, String dir
        while ((s = ri.readLine()) != null) {
            ss = s.split("\t");
            ls2 = new ArrayList();
            ls1 = new ArrayList();
            tt = ss[1].split(";");
            ls1.addAll(Arrays.asList(tt));
            tt = ss[6].split(";");
            ls2.addAll(Arrays.asList(tt));
            in = new Interaction(ss[0], ls1, this.nodes.get(ss[2]), this.nodes.get(ss[3]), ss[4], ss[5], ls2, ss[7], ss[8]);
            this.interactions.put(ss[0], in);
        }
        rn.close();
        ri.close();
    }

    /**
     * Saves all interactions and nodes in the network to the two output files
     *
     * @param nodef node file
     * @param intf interaction file
     * @throws IOException
     */
    public void saveNetworktofile(String nodef, String intf) throws IOException {
        BufferedWriter wn = new BufferedWriter(new FileWriter(nodef));
        BufferedWriter wi = new BufferedWriter(new FileWriter(intf));

        for (Node n : this.nodes.values()) {
            try {
                wn.write(n.toString());
            } catch (NullPointerException e) {
                System.out.println(n.id + n.db_flag);
            }
            wn.newLine();
        }

        for (Interaction in : this.interactions.values()) {
            wi.write(in.toString());
            wi.newLine();
        }

        wn.close();
        wi.close();
    }

    /**
     * Remove all interactions and nodes from network
     */
    public void removeAll() {
        for (String s : this.interactions.keySet()) {
            this.interactions.remove(s);
        }
        for (String s : this.nodes.keySet()) {
            this.nodes.remove(s);
        }
    }

    /**
     * Load network from databases
     *
     * @param nutils NetworkTools object
     * @param putils PathwayTools object
     * @param outils OverrepresentedTools object
     * @param dbutils DBkTools object
     * @throws IOException
     */
    public void loadNetwork2(NetworkManager nutils, PathwayManager putils, CentralityManager outils, DBManager dbutils) throws IOException {
        Network all=new Network();
        dbutils.loadHPRD();
        //dbutils.loadTRANSPATH();
        dbutils.loadHIPPIE(false);
        dbutils.loadSignor();
        dbutils.loadSignalink();

        dbutils.loadKEGG();
         dbutils.loadTransmir();
        dbutils.loadmirTarBase();
        dbutils.loadtFacts();
        List<Network> networks = new ArrayList();
        
        networks.add(dbutils.hprd);
        // networks.add(dbutils.hippie_high);
       // networks.add(dbutils.hippie_medium_meq);
        // networks.add(dbutils.hippie_medium_m);
        //networks.add(dbutils.hippie_medium_m0);
        networks.add(dbutils.hippie);
        
        
        networks.add(dbutils.signor);
        networks.add(dbutils.signalink);
        networks.add(dbutils.kegg);
        networks.add(dbutils.transmir);
        networks.add(dbutils.mirtarbase);
        networks.add(dbutils.tfacts);
        
        //all = nutils.merge_list_of_networks(networks);
        nutils.buildNeighbours(all);
        nutils.add_genes_and_products(all);
        nutils.buildNeighbours(all);
        this.interactions = all.interactions;
        this.nodes = all.nodes;
        all = null;

    }

}
